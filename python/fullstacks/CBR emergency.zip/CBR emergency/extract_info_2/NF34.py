# @author: "QiuJunan"
# @date: 2018/3/17 10:35

from ExSQL import EXSQL         #导入EXSQL类
import datetime
import re
from c2a import c2a
import jieba.posseg as pseg

class Record(object):
    """
    解析一条案例，获取以下属性
    """
    def __init__(self,title,db=None):
        self.title = title      #案例名称（标题）
        self.Nno = None         #案例编号
        self.entype = None      #事件分类
        self.title_time = None  #事件标题中的年份，一般是具体到哪一年
        self.least_time = None  #最小时间
        self.first_time = None  #文中第一次出现的时间
        self.palce = None       #发生地点
        self.news = None        #案例描述
        self.death = None       #人员伤亡
        self.loss = None        #经济损失
        self.tdeath = None      #？？？
        self.db = db            #EXSQL类的对象
        #还有一些属性，这里还没有涉及。

    def get_basic_info(self,select="*"):
        """
        获取一些基本的信息，也就是原始数据提供的一些基本信息，目前包含四个
        :param select: 默认为所有字段，可以设置
        :return: 无返回值
        """
        select = 'case_id,title,content,title_time'   #具体需要根据数据库字段进行修改
        record = self.db.search_one_by_title(self.title,select)
        if record:  #当获取到的时候才赋值
            self.Nno,self.title,self.news,self.title_time = record

    def get_time(self):
        """
        获取最小时间，第一时间并赋值。
        :return:
        """
        try:
            #看数据库中是否存在title_time,存在的话是int类型
            self.first_time,self.least_time = Record._get_times(self.title_time,self.title+self.news)
            self.least_time = self.least_time.translate(str.maketrans('０１２３４５６７８９','0123456789'))
        except Exception as e:
            print("get_time Error:",e)
            #当没有最小时间的时候赋值为None。
            self.least_time = None

    @staticmethod
    def _get_times(title_time,news):
        """
        静态方法，传入标题时间和新闻内容，从新闻内容中提取最小时间和第一时间并返回
        :param title_time:
        :param news:
        :return:
        """
        try:
            pattern_year = re.compile('\d{4}年\d{1,2}月')
            years = re.findall(pattern_year,news)
            #如果title_time为空，且文中找到"XXXX年XX月"
            if years and not title_time:
                title_time = years[0][0:4]
            pattern = re.compile('\d{1,2}月\d{1,2}[日|号]|[一二三四五六七八九十]月[一二三四五六七八九十][日|号]')
            # 使用()将一整个部分括起来，然后添加次数，如果不需要捕获可以添加?:
            # pattern = re.compile('(?:\d{2,4}年){0,}\d{1,2}月\d{1,2}[日|号]|(?:\d{2,4}年){0,}[一二三四五六七八九十]月[一二三四五六七八九十][日|号]')
            times = re.findall(pattern,news)
            # print("title_time=",title_time,"文中出现的月日列表=",times)
            # 将时间中的年月日前面如果是数字，就转换成对应的阿拉伯数字，并替换为-
            for i in range(len(times)):
                try:
                    temp = c2a([times[i]])[0]
                    times[i] = temp.replace("年","-").replace("月","-").replace("日","").replace("号","")
                except:
                    times[i] = times[i] = temp.replace("年","-").replace("月","-").replace("日","").replace("号","")
            return Record._get_first_time(title_time,times),Record._get_least_time(title_time,times)

        except Exception as e:
            print(e)

    @staticmethod
    def _get_first_time(title_time,times):
        """
        获取第一个时间
        :param title_time: 标题中的时间,字符串
        :param cur_time: 事件中出现的 月-日 时间列表
        :return:
        """
        try:
            if not times:
                #如果文中没有出现时间，就返回标题中的时间
                return title_time

            if not title_time:
                # 如果没有年份，那么就不用在找月份了，没有意义。
                return None

            month = times[0].split("-")[0]  #保存月份和日
            day = times[0].split("-")[1]

            if int(month)<10 and len(month)!=2:
                month = '0'+month
            if int(day) < 10 and len(day) != 2:
                day = '0' + day

            # print("第一时间为:",str(title_time) + "-"+month +"-"+ day)
            return str(title_time) + "-"+month +"-"+ day

        except Exception as e:
            print("_get_first_time Error:",e)

    @staticmethod
    def _get_least_time(title_time,times):
        """
        获取最小时间
        :param title_time: 标题中的时间，可能为空
        :param times: 新闻中出现的  月-日 格式的时间列表
        :return:
        """
        try:
            if not times:
                # 如果文中没有出现时间，就返回标题中的时间
                return title_time

            if not title_time:
                # 如果没有年份，那么就不用在找月份了，没有意义。
                return None

            timelist = []

            for i in range(len(times)):
                # 保存所有的月份和日
                time = {}
                time["month"] = times[i].split("-")[0]
                time["day"] = times[i].split("-")[1]
                timelist.append(time)

            min_time = 10000
            for time in timelist:
                # 转换成标准格式，如0916表示9月16
                if int(time["month"])<10 and len(time["month"])!=2:
                    time["month"] = '0'+time["month"]
                if int(time["day"])<10 and len(time["day"])!=2:
                    time["day"] = '0'+time["day"]

                #转换成数字进行比较，如0916 和 0826直接进行大小比较即可
                if int(time["month"]+time["day"])<min_time:
                    min_time = int(time["month"]+time["day"])

            #左侧位数不够时，补0
            min_time  = str(min_time).zfill(4)
            # print("最小时间为:",str(title_time)+"-"+str(min_time)[:2]+"-"+str(min_time)[2:])
            return str(title_time)+"-"+str(min_time)[:2]+"-"+str(min_time)[2:]

        except Exception as e:
            print("_get_least_time Error:",e)

    def get_place(self):
        """
        获取发生地点信息
        :return:
        """
        # 换一个思路，找出含有这些词的字符串，然后从新闻中删除，然后在进行地名的处理
        pattern = re.compile('(?:中国|美国|报道|期刊|刊).{2,4}网')#设定表达式，除去报刊，当加上nr中含的地名影响
        string = re.findall(pattern,self.title+self.news)   #返回一个列表
        results = self.title+self.news
        if string:  # 如果存在匹配结果，那么就进行删除
            for i in string:
                print(i)
                index = self.news.index(i)
                results = results[:index]+results[index+len(i):]
        f = pseg.cut(results)                                #词性标注
        result = []
        flag = []
        count = 0
        for word,cixin in f:
            if count == 0:    # 如果找到一个符合if条件的之后，count就会自增然后在下一次循环时就执行else语句
                if cixin == 'ns' and word not in ["台风","哥哥","悉","小乖乖"]:# 词性ns表示地名，弥补jieba分词不足
                    result.append(word)
                    flag.append(1)
                    count +=1
            else:
                if (cixin == 'ns' or cixin == 'nr') and word not in ["台风","哥哥","悉","小乖乖"]:  # nr表示人名
                    result.append(word)
                    flag.append(1)
                else:
                    if flag: # 如果找到符合条件的，就在flag后面添加一个标志位 0
                        flag.append(0)
                    else: # flag为空，表示没有搜寻到地名或者人名信息
                        flag = [1]  # 【S】我觉得这里应该是这样写
                if not all(flag):  # 如果flag中存在一个为0，则执行下面的语句。
                    self.place = "".join(result)
                    return

        if not result:
            self.place = ""
            return


if __name__ == '__main__':
    record = Record('“漳州男子追小偷致其身亡”事件舆情分析',EXSQL())
    record.get_basic_info()
    record.get_time()
    record.get_place()
    print("最小时间=",record.least_time," 第一时间=",record.first_time,"地名=",record.place)
    # print(record.Nno,record.title,record.news,record.title_time)